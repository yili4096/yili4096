package veeva.htmlreport;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

/**
 * 
 * 采取一步一步进行引导操作
 *
 */
public class CallPlanningSummary {

	final static String newline = "\n";
	static JTextArea jTextArea = new JTextArea("请输入内容", 30, 145);
	static JTextField territoryNameTextField;
	static JPanel jPanel = new JPanel();
	static JButton createCyclePlanSqlBtn = new JButton("1 CyclePlan导出脚本");
	static JButton cyclePlanCsvImportBtn = new JButton("2 CyclePlan导入");
	static JButton cyclePlanTargetCsvImportBtn = new JButton("3 CyclePlanTarget导入");
	static JButton cyclePlanChannelCsvImportBtn = new JButton("4 CyclePlanChannel导入");
	static JButton cyclePlanProductCsvImportBtn = new JButton("5 CyclePlanProduct导入");
	static JButton productMetrixCsvImportBtn = new JButton("6 ProductMetrix导入");
	static JButton productCsvImportBtn = new JButton("7 Product导入");
	static JButton accountCsvImportBtn = new JButton("8 Account导入");
	static JButton callBtn = new JButton("9 Call导入");
	static JButton exportCPDTotal = new JButton("==> exportCPDTotal 总数");
	static JButton exportForTieredCPDTotal = new JButton("==>exportCPD for Tiered Total");
	static JButton exporTab2_4 = new JButton("==> Tab2_4");

	static JFrame jFrame = new JFrame("CallPlanning Summary");

	public static void main(String[] args) {

		jTextArea.setLineWrap(true); // 设置文本域中的文本为自动换行
		jTextArea.setForeground(Color.BLACK);
		jTextArea.setFont(new Font("宋体", Font.LAYOUT_LEFT_TO_RIGHT, 12));
//		jTextArea.setBackground(Color.gray);
		JScrollPane jScrollPane = new JScrollPane(jTextArea);
		Dimension size = jTextArea.getPreferredSize();
		jScrollPane.setBounds(110, 50, size.width, size.height);
		jPanel.add(jScrollPane); //// 将JScrollPane添加到JPanel容器中

		jFrame.setBackground(Color.LIGHT_GRAY);
		jFrame.setSize(900, 600);
		jFrame.setVisible(true);

		append("start...");
		append("在输入框输 territory name, 再点击执行");

		// 向JPanel中添加FlowLayout布局管理器，将组件间的横向和纵向间隙设置为20像素
		jPanel.setLayout(new FlowLayout(FlowLayout.LEADING, 5, 20));
		jPanel.setBackground(Color.gray);
		jFrame.add(jPanel);
		jFrame.setBounds(500, 100, 920, 650);

		jFrame.setVisible(true);
		jFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		initTerritoryNameTextField();
		initCreateCyclePlanSqlBtn();
		initCyclePlanCsvImportBtn();
		initCyclePlanTargetCsvImportBtn();
		initCyclePlanChannelCsvImportBtn();
		initCyclePlanProductCsvImportBtn();
		initProductMetrixCsvImportBtn();
		initProductCsvImportBtn();
		initAccountCsvImportBtn();
		initCallBtn();
		initExportCPDTotal();
		initExportTab2GoalDonut();
		initExportTab2_4();
		repaintUI();
	}

	private static void repaintUI() {
		jFrame.add(jPanel);
		jFrame.invalidate();
		jFrame.validate();
		jFrame.repaint();
	}

	/**
	 * 导入cyclePlan
	 */
	private static void initTerritoryNameTextField() {
		territoryNameTextField = new JTextField("输入 territory name");
		territoryNameTextField.setPreferredSize(territoryNameTextField.getPreferredSize());
		territoryNameTextField.setText(Constants.TERRITORY_NAME);
		territoryNameTextField.setSize(150, 30);
		jPanel.add(territoryNameTextField);
	}

	/**
	 * 导入cyclePlan
	 */
	private static void initCreateCyclePlanSqlBtn() {
		createCyclePlanSqlBtn.setText("在输入框输 territory name, 再点击执行");
		jPanel.add(createCyclePlanSqlBtn);
		createCyclePlanSqlBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				createCyclePlanSqlBtn.setBackground(Color.green);
//				createCyclePlanSqlBtn.setEnabled(false);
				append("请执行", "select Id, Name, Start_Date_vod__c, End_Date_vod__c, Territory_vod__c, OwnerId from MC_Cycle_Plan_vod__c where Status_vod__c = 'In_Progress_vod' " + "  and Territory_vod__c = '"
						+ territoryNameTextField.getText() + "'");
				append("将上述文件导入如下文件，并点击执行 CyclePlan导入   ", Constants.getCyclePlanFile());
			}
		});
	}

	private static String cyclePlanId = null;

	private static String startDate = null;
	private static String endDate = null;

	/**
	 * 导入cyclePlanCsvImportBtn
	 */
	private static void initCyclePlanCsvImportBtn() {
		jPanel.add(cyclePlanCsvImportBtn);
		cyclePlanCsvImportBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cyclePlanCsvImportBtn.setBackground(Color.green);
//				createCyclePlanSqlBtn.setEnabled(false);
				List<String[]> cyclePlanList = CsvTools.readCsv(Constants.CYCLE_PLAN);
				for (int index = 1; index < cyclePlanList.size(); index++) {
					cyclePlanId = cyclePlanList.get(index)[1];

					startDate = cyclePlanList.get(index)[3];
					endDate = cyclePlanList.get(index)[4];
				}
				append("导入成功，cyclePlanId：" + cyclePlanId);
				append("请执行", " select Id, Cycle_Plan_vod__c, Target_vod__c from MC_Cycle_Plan_Target_vod__c where Cycle_Plan_vod__c = '" + cyclePlanId + "'");
				append("将上述文件导入如下文件，并点击执行    ", Constants.getCyclePlanTargetFile());
			}
		});
	}

	private static List<String> accountList = new ArrayList<String>();
	private static Map<String, String> targetAccountMap = new HashMap<String, String>();

	/**
	 * 导入cyclePlanTargetCsvImportBtn select Id, Cycle_Plan_vod__c, Target_vod__c
	 * from MC_Cycle_Plan_Target_vod__c
	 */
	private static void initCyclePlanTargetCsvImportBtn() {
		jPanel.add(cyclePlanTargetCsvImportBtn);
		cyclePlanTargetCsvImportBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cyclePlanTargetCsvImportBtn.setBackground(Color.green);
//				cyclePlanCsvImportBtn.setEnabled(false);
				List<String[]> cyclePlanTargetList = CsvTools.readCsv(Constants.CYCLE_PLAN_TARGET);
				List<String> cyclePlanTargetIdList = new ArrayList<String>();
				String accountTemp = null;
				String cyclePlanTargetId = null;
				boolean skip = true;
				for (String[] arr : cyclePlanTargetList) {
					if (skip) {
						skip = !skip;
						continue;
					}
					cyclePlanTargetId = "'".concat(arr[1]).concat("'");
					cyclePlanTargetIdList.add(cyclePlanTargetId);

					accountTemp = "'".concat(arr[3]).concat("'");
					if (!accountList.contains(accountTemp)) {
						accountList.add(accountTemp);
					}

					targetAccountMap.put(arr[1], arr[3]);
				}

				append("导入" + Constants.CYCLE_PLAN_TARGET + "成功");
				append("请执行", "  select Id, Name, Channel_vod__c, Cycle_Plan_Target_vod__c from MC_Cycle_Plan_Channel_vod__c where Cycle_Plan_Target_vod__c in (" + String.join(",", cyclePlanTargetIdList) + ")");
				append("将上述文件导入如下文件，并点击执行    ", Constants.getCyclePlanChannelFile());
			}
		});
	}

	private static Map<String, String> channelAccountMap = new HashMap<String, String>();

	/**
	 * 导入cyclePlanChannelCsvImportBtn select Id, Name, Channel_vod__c,
	 * Cycle_Plan_Target_vod__c from MC_Cycle_Plan_Channel_vod__c
	 */
	private static void initCyclePlanChannelCsvImportBtn() {
		jPanel.add(cyclePlanChannelCsvImportBtn);
		cyclePlanChannelCsvImportBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cyclePlanChannelCsvImportBtn.setBackground(Color.green);
//				cyclePlanCsvImportBtn.setEnabled(false);
				List<String[]> cyclePlanChannelList = CsvTools.readCsv(Constants.CYCLE_PLAN_CHANNEL);
				List<String> cyclePlanChannelIdList = new ArrayList<String>();
				boolean skip = true;
				for (String[] arr : cyclePlanChannelList) {
					if (skip) {
						skip = !skip;
						continue;
					}
					cyclePlanChannelIdList.add("'".concat(arr[1]).concat("'"));

					channelAccountMap.put(arr[1], targetAccountMap.get(arr[4]));
				}
				append();
				append("导入" + Constants.CYCLE_PLAN_CHANNEL + "成功");
				append("请执行", " select Id, Cycle_Product_vod__c, Cycle_Plan_Channel_vod__c,Activity_Goal_Edit_vod__c,Product_Activity_Goal_vod__c from MC_Cycle_Plan_Product_vod__c where Cycle_Plan_Channel_vod__c  in ("
						+ String.join(",", cyclePlanChannelIdList) + ")");
				append("将上述文件导入如下文件，并点击执行    ", Constants.getCyclePlanProductFile());
			}
		});
	}

	private static List<String[]> productList = null;

	/**
	 * 导入cyclePlanProductCsvImportBtn select Id, Cycle_Product_vod__c,
	 * Cycle_Plan_Channel_vod__c,Activity_Goal_Edit_vod__c,Product_Activity_Goal_vod__c
	 * from MC_Cycle_Plan_Product_vod__c
	 */
	private static void initCyclePlanProductCsvImportBtn() {
		jPanel.add(cyclePlanProductCsvImportBtn);
		cyclePlanProductCsvImportBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cyclePlanProductCsvImportBtn.setBackground(Color.green);
//				cyclePlanCsvImportBtn.setEnabled(false);
				productList = CsvTools.readCsv(Constants.CYCLE_PLAN_PRODUCT);

				append();
				append("导入" + Constants.CYCLE_PLAN_PRODUCT + "成功");

				append(5);
				append("請注意如下文件的處理。。。");
				append(10);
				append("请执行", " select Id, Product_vod__c, Product_vod__r.Name from MC_Cycle_Product_vod__c ");
				append("将上述文件导入如下文件", Constants.getProductFile(), "点击执行", "Product导入");

				append(3);
				append("请执行", " select Id, Name, Tier_Rating_BMS_US__c, Products_vod__c, Account_vod__c from Product_Metrics_vod__c where Account_vod__c in (" + String.join(",", accountList) + ")");
				append("将上述文件导入如下文件", Constants.getProductMetrixFile(), "点击执行", "ProductMetrix导入");

				append(3);
				append("请执行 ", "select id, name,Specialty_1_vod__c from Account where id in (" + String.join(",", accountList) + ")");
				append("将上述文件导入如下文件", Constants.getAccountFile(), "点击执行", "Account导入");

				append(3);
				StringBuffer callSqlBuf = new StringBuffer(" select Id, Call2_vod__c, Call2_vod__r.Account_vod__c, Call2_vod__r.Account_vod__r.Name, Product_vod__c,Product_vod__r.Name ");
				callSqlBuf.append(" from Call2_Detail_vod__c where Call2_vod__r.Status_vod__c= 'Submitted_vod' ");
				callSqlBuf.append(" and Call2_vod__r.Call_Date_vod__c	>= ").append(startDate);
				callSqlBuf.append(" and Call2_vod__r.Call_Date_vod__c	<= ").append(endDate);
				append("请执行 ", callSqlBuf.toString());
				append("将上述文件导入如下文件", Constants.getCallFile(), "点击执行", "Call导入");
			}
		});
	}

	private static Map<String, String> productAccountMetricsHasTierMap = new HashMap<String, String>();
	private static Map<String, String> productAccountMetricsMap = new HashMap<String, String>();

	/**
	 * 导入productMetrixCsvImportBtn select Id, Name, Tier_Rating_BMS_US__c,
	 * Products_vod__c, Account_vod__c
	 */
	private static void initProductMetrixCsvImportBtn() {
		jPanel.add(productMetrixCsvImportBtn);
		productMetrixCsvImportBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				productMetrixCsvImportBtn.setBackground(Color.green);
//				cyclePlanCsvImportBtn.setEnabled(false);
				List<String[]> metrixList = CsvTools.readCsv(Constants.PRODUCT_METRIX);
				boolean skip = true;
				String tier = null;
				String productEach = null;
				String accountEach = null;

				for (String[] arr : metrixList) {
					if (skip) {
						skip = !skip;
						continue;
					}
					tier = arr[3];
					productEach = arr[4];
					accountEach = arr[5];
					productAccountMetricsMap.put(productEach + accountEach, tier);
					if (StringUtil.isNotEmpty(tier)) {
						productAccountMetricsHasTierMap.put(productEach + accountEach, tier);
					}
				}
				append();
				append("导入" + Constants.PRODUCT_METRIX + "成功");
			}
		});
	}

	private static Map<String, String> cycleProductAndProductIdMap = new HashMap<String, String>();
	private static Map<String, String> productIdNameMap = new HashMap<String, String>();

	/**
	 * 导入productCsvImportBtn select Id, Product_vod__c, Product_vod__r.Name from
	 * MC_Cycle_Product_vod__c
	 */
	private static void initProductCsvImportBtn() {
		jPanel.add(productCsvImportBtn);
		productCsvImportBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				productCsvImportBtn.setBackground(Color.green);
//				cyclePlanCsvImportBtn.setEnabled(false);
				// select Id, Product_vod__c, Product_vod__r.Name from MC_Cycle_Product_vod__c
				List<String[]> cyclePlanChannelList = CsvTools.readCsv(Constants.PRODUCT);
				List<String> cyclePlanTargetIdList = new ArrayList<String>();
				for (int index = 1; index < cyclePlanChannelList.size(); index++) {
					cyclePlanTargetIdList.add(cyclePlanChannelList.get(index)[1]);

					cycleProductAndProductIdMap.put(cyclePlanChannelList.get(index)[1], cyclePlanChannelList.get(index)[2]);
					productIdNameMap.put(cyclePlanChannelList.get(index)[2], cyclePlanChannelList.get(index)[4]);
				}
				append();
				append("导入" + Constants.PRODUCT + "成功");
			}
		});
	}

	private static Map<String, String> accountIdNameMap = new HashMap<String, String>();
	private static Map<String, String> accountSpecialtyMap = new HashMap<String, String>();

	/**
	 * 导入accountCsvImportBtn select id, name,Specialty_1_vod__c from Account
	 */
	private static void initAccountCsvImportBtn() {
		jPanel.add(accountCsvImportBtn);
		accountCsvImportBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				accountCsvImportBtn.setBackground(Color.green);
//				cyclePlanCsvImportBtn.setEnabled(false);
				List<String[]> accountList = CsvTools.readCsv(Constants.ACCOUNT);
				List<String> cyclePlanTargetIdList = new ArrayList<String>();
				for (int index = 1; index < accountList.size(); index++) {
					cyclePlanTargetIdList.add(accountList.get(index)[1]);

					accountIdNameMap.put(accountList.get(index)[1], accountList.get(index)[2]);
					accountSpecialtyMap.put(accountList.get(index)[1], accountList.get(index)[3]);
				}
				append();
				append("导入", Constants.ACCOUNT, "成功");
			}
		});
	}

	private static Map<String, Integer> productAccountCallMap = new HashMap<String, Integer>();
	private static Map<String, Integer> specialCallMap = new HashMap<String, Integer>();
	private static Map<String, Integer> tierCallMap = new HashMap<String, Integer>();

	/**
	 * 导入callBtn select Id, Call2_vod__c, Call2_vod__r.Account_vod__c,
	 * Call2_vod__r.Account_vod__r.Name, Product_vod__c,Product_vod__r.Name from
	 * Call2_Detail_vod__c
	 * 
	 * _ Id Call2_vod__c Call2_vod__r Call2_vod__r.Account_vod__c
	 * Call2_vod__r.Account_vod__r Call2_vod__r.Account_vod__r.Name Product_vod__c
	 * Product_vod__r Product_vod__r.Name Call2_Detail_vod__c a0G180000035A5mEAE
	 * a0418000002SwRrAAK Call2_vod__c 001U000000KLtXfIAL Account Sandeep Agarwal
	 * a00U0000002nyAoIAI Product_vod__c ORENCIA IV
	 */
	private static void initCallBtn() {
		jPanel.add(callBtn);
		callBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				callBtn.setBackground(Color.green);
//				cyclePlanCsvImportBtn.setEnabled(false);
				List<String[]> callList = CsvTools.readCsv(Constants.CALL);

				boolean skip = true;
				String key = null;
//				String productId = null;
//				String accountId = null;
				productAccountCallMap = new HashMap<String, Integer>();
				for (String[] item : callList) {
					if (skip) {
						skip = !skip;
						continue;
					}
					key = item[7] + item[4];

					Integer callCount = productAccountCallMap.get(key);
					if (callCount == null) {
						callCount = 0;
					}
					productAccountCallMap.put(key, callCount + 1);
					
					
					String specialtyName = item[6];
					if (StringUtil.isEmpty(specialtyName)) {
						specialtyName = Constants.NO_TIER;
					}
					Integer specialtyCount = specialCallMap.get(specialtyName);
					if (specialtyCount == null) {
						specialtyCount = 0;
					}
					specialCallMap.put(specialtyName, specialtyCount + 1);
					
					
					
					String productId = cycleProductAndProductIdMap.get(item[7]);
					String accountId = channelAccountMap.get(item[4]);
					
					
					String tier = productAccountMetricsHasTierMap.get(productId + accountId);
					if (StringUtil.isEmpty(tier)) {
						tier = Constants.NO_TIER;
					}
					Integer tierCount = tierCallMap.get(tier);
					if (tierCount == null) {
						tierCount = 0;
					}
					tierCallMap.put(tier, tierCount + 1);
					
					
					
					System.out.println(key + "-------" + callCount + 1);
				}
				append();
				append("导入", Constants.CALL, "成功");
			}
		});
	}

	/**
	 * 导入CPD GOAL
	 */
	private static void initExportCPDTotal() {
		jPanel.add(exportCPDTotal);
		exportCPDTotal.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				exportCPDTotal.setBackground(Color.green);

				CsvTools.createWriteFile(Constants.EXP_TOTAL_GOAL);

				// Id, Cycle_Product_vod__c,
				// Cycle_Plan_Channel_vod__c,Activity_Goal_Edit_vod__c,Product_Activity_Goal_vod__c
				// from MC_Cycle_Plan_Product_vod__c
				boolean skip = true;
				String productId = null;
				String productName = "productName";
				String accountId = null;
				String accountName = "accountName";
				String tier = "tier";
				String specialtyName = "specialtyName";
				String isMetrixMatched = "是否有对应的metrix";
				int total = 0;
				for (String[] arr : productList) {
					if (skip) {
						skip = !skip;
						String[] out = addElements(arr, productName, accountName, specialtyName, tier, "goal", isMetrixMatched);
						CsvTools.writeFileToCsv(out, Constants.getExpTotalGoalFile());
						continue;
					}
					productId = cycleProductAndProductIdMap.get(arr[2]);
					productName = productIdNameMap.get(productId);
					accountId = channelAccountMap.get(arr[3]);
					accountName = accountIdNameMap.get(accountId);
					specialtyName = accountSpecialtyMap.get(accountId);
					tier = productAccountMetricsHasTierMap.get(productId + accountId);
					isMetrixMatched = productAccountMetricsMap.containsKey(productId + accountId) ? "Yes" : "No";
					int goal = calGoal(arr[4], arr[5]);
					total += goal;
					String[] out = addElements(arr, productName, accountName, specialtyName, tier, String.valueOf(goal), isMetrixMatched);
					CsvTools.writeFileToCsv(out, Constants.getExpTotalGoalFile());
				}
				CsvTools.writeFileToCsv(new String[] { "total goal:".concat(String.valueOf(total)) }, Constants.getExpTotalGoalFile());
				append("导入", Constants.EXP_TOTAL_GOAL, "成功");

			}
		});
	}

	private static void initExportTab2GoalDonut() {
		jPanel.add(exportForTieredCPDTotal);
		exportForTieredCPDTotal.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				exportForTieredCPDTotal.setBackground(Color.green);

				CsvTools.createWriteFile(Constants.EXP_CALL_BASEINFO);
				CsvTools.createWriteFile(Constants.EXP_TAB2_3);

				// Id, Cycle_Product_vod__c,
				// Cycle_Plan_Channel_vod__c,Activity_Goal_Edit_vod__c,Product_Activity_Goal_vod__c
				// from MC_Cycle_Plan_Product_vod__c
				boolean skip = true;
				String productId = null;
				String productName = null;
				String accountId = null;
				String accountName = null;
				String key = null;
				Map<String, List<String[]>> productAccountCycProListMap = new HashMap<String, List<String[]>>();
				List<String[]> productAccountTargetList = null;
				for (String[] arr : productList) {
					if (skip) {
						skip = !skip;
						continue;
					}
					productId = cycleProductAndProductIdMap.get(arr[2]);
					accountId = channelAccountMap.get(arr[3]);
					key = productId + accountId;
					productAccountTargetList = productAccountCycProListMap.get(key);
					if (productAccountTargetList == null) {
						productAccountTargetList = new ArrayList<String[]>();
						productAccountCycProListMap.put(key, productAccountTargetList);
					}
					productAccountTargetList.add(arr);
				}

				// init the title
				String[] title = new String[] { "", "cycleProductId", "cycleProductId", "ChannelId", "EditGoal", "ViewGoal", "productName", "accountName", "specialtyName", "tier", "goal", "call", "isMetrixMatched", "overCall",
						"performance", "remaining" };
				CsvTools.writeFileToCsv(title, Constants.getExpCallFile());
				CsvTools.writeFileToCsv(title, Constants.getExpTab2_3File());

				String tier = "tier";
				String specialtyName = "specialtyName";
				String isMetrixMatched = "是否有对应的metrix";

				for (String productAccount : productAccountCycProListMap.keySet()) {
					List<String[]> arrList = productAccountCycProListMap.get(productAccount);
//					String[] out = null;
					boolean isFirstLine = true;
					String[] firstLine = null;
					int goal = 0;
					for (String[] arr : arrList) {

						if (isFirstLine) {
							firstLine = arr;
							productId = cycleProductAndProductIdMap.get(firstLine[2]);
							productName = productIdNameMap.get(productId);
							accountId = channelAccountMap.get(firstLine[3]);
							accountName = accountIdNameMap.get(accountId);
							specialtyName = accountSpecialtyMap.get(accountId);
							tier = productAccountMetricsHasTierMap.get(productId + accountId);
							isMetrixMatched = productAccountMetricsMap.containsKey(productId + accountId) ? "Yes" : "No";
							goal = 0;
							key = productId + accountId;
						}
						goal += calGoal(arr[4], arr[5]);
					}
					Integer call = productAccountCallMap.get(key);
					if (null == call) {
						call = 0;
					}

					// over call
					int overCall = call > goal ? call - goal : 0;
					int performance = Math.min(call, goal);
					// Remaining
					int remaining = call < goal ? goal - call : 0;

					String[] out = addElements(firstLine, productName, accountName, specialtyName, tier, String.valueOf(goal), String.valueOf(call), isMetrixMatched, String.valueOf(overCall), String.valueOf(performance),
							String.valueOf(remaining));
					CsvTools.writeFileToCsv(out, Constants.getExpCallFile());
					
					// If this record has Tier Value(The tier in productMetix), this record will be recorded in another file
					if (productAccountMetricsHasTierMap.containsKey(key)) {
						CsvTools.writeFileToCsv(out, Constants.getExpTab2_3File());
					}
				}

				append("导入", Constants.EXP_TOTAL_GOAL, "成功");

			}
		});
	}

	private static void initExportTab2_4() {
		jPanel.add(exporTab2_4);
		exporTab2_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				exporTab2_4.setBackground(Color.green);

				CsvTools.createWriteFile(Constants.EXP_TAB2_4);
				CsvTools.createWriteFile(Constants.EXP_TAB2_5);

				boolean skip = true;
				String productId = null;
				String accountId = null;
				
				
				String specialName = null;
				Map<String, Integer> specialGoalMap = new HashMap<String, Integer>();
				Map<String, Integer> tierGoalMap = new HashMap<String, Integer>();
				for (String[] arr : productList) {
					if (skip) {
						skip = !skip;
						continue;
					}
					accountId = channelAccountMap.get(arr[3]);
					productId = cycleProductAndProductIdMap.get(arr[2]);
					
					specialName = accountSpecialtyMap.get(accountId);
					if (StringUtil.isEmpty(specialName)) {
						specialName = Constants.NO_SPECIALTY;
					}
					Integer specialGoal = specialGoalMap.get(specialName);
					if (specialGoal == null) {
						specialGoal = 0;
					}
					specialGoal += calGoal(arr[4], arr[5]);
					specialGoalMap.put(specialName, specialGoal);
					
					String tier = productAccountMetricsHasTierMap.get(productId + accountId);
					if (StringUtil.isEmpty(tier)) {
						tier = Constants.NO_TIER;
					}
					Integer tierGoal = tierGoalMap.get(specialName);
					if (tierGoal == null) {
						tierGoal = 0;
					}
					tierGoal += calGoal(arr[4], arr[5]);
					tierGoalMap.put(tier, tierGoal);
				}
				
				
				for (String specialtyName : specialGoalMap.keySet()) {
					String[] out = new String[] {specialtyName, String.valueOf(specialGoalMap.get(specialName)), String.valueOf(specialCallMap.get(specialName))};
					CsvTools.writeFileToCsv(out, Constants.getExpTab2_4File());
				}
				
				
				for (String tierName : tierGoalMap.keySet()) {
					String[] out = new String[] {tierName, String.valueOf(tierGoalMap.get(tierName)), String.valueOf(tierCallMap.get(tierName))};
					CsvTools.writeFileToCsv(out, Constants.getExpTab2_5File());
				}

				append("第四五生成", "成功");
			}
		});
	}
	
	private static String[] addElements(String[] ori, String... addE) {
		int length = addE.length;
		int oriLength = ori.length;
		String[] oriNew = Arrays.copyOf(ori, ori.length + length);
		for (int index = 0; index < addE.length; index++) {
			oriNew[oriLength + index] = addE[index];
		}
		return oriNew;
	}

	private static int calGoal(String edit, String view) {
		int goal = 0;
		if (StringUtil.isNotEmpty(edit) && !"null".equalsIgnoreCase(edit)) {
			goal = new Integer(edit);
		} else if (StringUtil.isNotEmpty(view) && !"null".equalsIgnoreCase(view)) {
			goal = new Integer(view);
		}
		return goal;
	}

	private static void append(String... txt) {
		append();
		for (String s : txt) {
			jTextArea.append(s);
			jTextArea.append(newline);
		}
	}

	private static void append() {
		jTextArea.append(newline);
	}

	private static void append(int duplicateNo) {
		for (int i = 0; i < duplicateNo; i++)
			jTextArea.append(newline);
	}
}
