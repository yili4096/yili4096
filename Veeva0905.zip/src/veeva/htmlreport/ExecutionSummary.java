package veeva.htmlreport;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import au.com.bytecode.opencsv.CSVReader;
import au.com.bytecode.opencsv.CSVWriter;


public class ExecutionSummary {
	
	public static String FOLDER = "C:\\Users\\lim79\\Documents\\BMS\\Veeva\\MCCP_MyInsights_TESTDATA\\";
	public static String territoryName = "367128";
	
	
	
	// 4:product; 6:product_name; 10:account_id; 12:account_name; 13: specialty_name; 17:territory_name; 18:goal_edit 19:goal_view
	public static String PRODUCT = "product.csv";
	// 4:account_id; 7:product
	public static String CALL = "call.csv";
	// 3:tired_name;  4:product ; 5:account_id;
	public static String METRIX = "metrix.csv";
	// 1:ID; 3:specialty_name
	public static String ACCOUNT = "account.csv";
	public static String RE_CSV = FOLDER + (LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss"))) + "\\";
	
	private static CSVReader reader;

	public static void main(String[] args) {
		List<String[]> productList = readCsv(PRODUCT);
		List<String[]> callList = readCsv(CALL);
		List<String[]> metrixList = readCsv(METRIX);
		List<String[]> accountList = readCsv(ACCOUNT);

		File directory = new File(RE_CSV);
		if (!directory.exists()) {
			directory.mkdir();
		}
		
		String key = null;
		
		Set<String> hasTierSet = new HashSet<String>();
		Map<String, Set<String>> tierProductAccountSetMap = new HashMap<String, Set<String>>();
		Map<String, String> productAccountTierMap = new HashMap<String, String>();
		String tier = null;
		// 3:tired_name; 4:account_id; 5:product
		for (String[] item : metrixList) {
			// productId_accountId
			key = item[4] + item[5];
			tier = StringUtil.isNotEmpty(item[3]) ?  item[3] : "No Tier";
			if (!"No Tier".equals(tier)) {
//				productAccountHasTierMap.put(key, tier);
				hasTierSet.add(key);
			}
			
			Set<String> tierGroupSet = tierProductAccountSetMap.get(tier);
			if (tierGroupSet == null) {
				tierGroupSet = new HashSet<String>();
				tierProductAccountSetMap.put(tier, tierGroupSet);
			}
			tierGroupSet.add(key);
			
			// recorde tier
			productAccountTierMap.put(key, tier);
		}
		
		Map<String, String> accountIdSpeciatlyMap = new HashMap<String, String>();
		// Deal with account infor, create account_id, specialty_name
		for (String[] item : accountList) {
			accountIdSpeciatlyMap.put(item[1], item[3]);
		}
		
		
		Map<String, Integer> productAccountGoalMap = new HashMap<String, Integer>();
		Map<String, String[]> productAccountNameArrayMap = new HashMap<String, String[]>();
		Map<String, String> productNameMap = new HashMap<String, String>();
		Map<String, String> specialtyNameMap = new HashMap<String, String>();

		Map<String, Set<String>> specialtyProductsMap = new HashMap<String, Set<String>>();
		String accountName = null;
		Set<String> specialtyProductSet = null;
		// 4:product; 6:product_name; 10:account_id; 12:account_name; 13: specialty_name; 17:territory_name; 18:goal_edit 19:goal_view
		for (String[] item : productList) {
			if (!territoryName.equalsIgnoreCase(item[17])) {
				continue;
			}
			
			productNameMap.put(item[4], item[6]);
			specialtyNameMap.put(item[10], item[12]);
			// productId_accountId
			key = item[4] + item[10];
			accountName = item[12];
			productAccountNameArrayMap.put(key, new String[]{item[6], accountName});
			
			Integer goal = productAccountGoalMap.get(key);
			if (goal == null) {
				goal = 0;
			}
			productAccountGoalMap.put(key, goal + StringUtil.goal(item[18], item[19]));	
//			System.out.println(item[18] + "-------" + item[19] + "======" + StringUtil.goal(item[18], item[19]));
			
			String specialtyName = item[13];
			if (StringUtil.isEmpty(specialtyName)) {
				specialtyName = "No Specialty";
			}
			specialtyProductSet = specialtyProductsMap.get(specialtyName);
			if (null == specialtyProductSet) {
				specialtyProductSet = new HashSet<String>();
				specialtyProductsMap.put(specialtyName, specialtyProductSet);
			}
			specialtyProductSet.add(key);
		}
		// 4:account_id; 7:product
		Map<String, Integer> productAccountCallMap = new HashMap<String, Integer>();
		for (String[] item : callList) {
//			if (!productAccountNameArrayMap.containsKey(key)) {
//				continue;
//			}
			key = item[7] + item[4];
			Integer callCount = productAccountCallMap.get(key);
			if (callCount == null) {
				callCount = 0;
			}
			productAccountCallMap.put(key, callCount + 1);	
			System.out.println(key + "-------" + callCount + 1);
		}
		
		

		
		
		// 处理 第一、二、三个donut图
		String[] productNameArray = null;
		String writeFileName12 = createWriteFile("12");
		String writeFileName3 = createWriteFile("3");
		
		Integer eachGoalCount = null;
		Integer eachCallCount = null;
		
		// Write the Title
		String[] titleRow = new String[] {"Product_vod__c","Account_vod__c","Product Name","Account Name","Goals","Submited Calls","Overcall(F-E)","Goals Achieved","Total Calls Remaining(E-F)","Tier INFO", "Specialty Name"};
		writeFileToCsv(titleRow, writeFileName12);
		writeFileToCsv(titleRow, writeFileName3);
		
		for (String paKey : productAccountGoalMap.keySet()) {
			String[] eachRow = new String[12];
			productNameArray = productAccountNameArrayMap.get(paKey);
			eachRow[0] = paKey.substring(0, 18);	
			eachRow[1] = paKey.substring(18);	
			eachRow[2] = productNameArray[0];	
			eachRow[3] = productNameArray[1];
			eachGoalCount = productAccountGoalMap.get(paKey);
			eachCallCount = productAccountCallMap.get(paKey);
			if (null == eachGoalCount) {
				eachGoalCount = 0;
			}
			if (null == eachCallCount) {
				eachCallCount = 0;
			}
			eachRow[4] = String.valueOf(eachGoalCount);
			eachRow[5] = String.valueOf(eachCallCount);
			// over call
			eachRow[6] = String.valueOf(eachCallCount > eachGoalCount ? eachCallCount - eachGoalCount : 0);
			// performance
			eachRow[7] = String.valueOf(Math.min(eachCallCount, eachGoalCount));
			// Remaining
			eachRow[8] = String.valueOf(eachCallCount < eachGoalCount ? eachGoalCount - eachCallCount : 0);

			String tierColumn = productAccountTierMap.get(paKey);
			eachRow[9] = (tierColumn != null && !tierColumn.isEmpty())? tierColumn : "";
			
			String specialtyName = accountIdSpeciatlyMap.get(eachRow[1] );
			eachRow[10] = (specialtyName != null && !specialtyName.isEmpty())? specialtyName : "No Speicalty";

			writeFileToCsv(eachRow, writeFileName12);
			
			if (hasTierSet.contains(paKey)) {
				writeFileToCsv(eachRow, writeFileName3);
			}
		}
		
		System.out.println("123 OK");
		
		
		
		// 处理 第四个柱图
		String writeFileName4 = createWriteFile("4");
		for (String paKey : specialtyProductsMap.keySet()) {
			String[] eachRow = new String[8];
			Set<String> productAccountIdSet = specialtyProductsMap.get(paKey);
			int goalSum = 0;
			int callSum = 0;
			for (String it : productAccountIdSet) {
				eachGoalCount = productAccountGoalMap.get(it);
				eachCallCount = productAccountCallMap.get(it);
				if (null == eachGoalCount) {
					eachGoalCount = 0;
				}

				goalSum += eachGoalCount;
				
				if (null == eachCallCount) {
					eachCallCount = 0;
				}
				callSum += Math.min(eachCallCount, eachGoalCount);
			}
			eachRow[0] = paKey;
			eachRow[4] = String.valueOf(goalSum);
			eachRow[5] = String.valueOf(callSum);

			writeFileToCsv(eachRow, writeFileName4);
		}

		System.out.println("4 OK");
		
		// 处理 第五个柱图
		String writeFileName5 = createWriteFile("5");
		for (String paKey : tierProductAccountSetMap.keySet()) {
			String[] eachRow = new String[8];
			Set<String> productAccountIdSet = tierProductAccountSetMap.get(paKey);
			int goalSum = 0;
			int callSum = 0;
			for (String it : productAccountIdSet) {
				eachGoalCount = productAccountGoalMap.get(it);
				eachCallCount = productAccountCallMap.get(it);
				if (null == eachGoalCount) {
					eachGoalCount = 0;
				}

				goalSum += eachGoalCount;
				if (null == eachCallCount) {
					eachCallCount = 0;
				}
//				callSum += eachCallCount;
				callSum += Math.min(eachCallCount, eachGoalCount);
			}
			eachRow[0] = paKey;
			eachRow[4] = String.valueOf(goalSum);
			eachRow[5] = String.valueOf(callSum);

			writeFileToCsv(eachRow, writeFileName5);
		}

		System.out.println("5 OK");
		
	}

	
	public static String createWriteFile(String tag) {
		String fileName = tag + ".csv";
		try {
	         File file2 = new File(RE_CSV, fileName);
	         file2.createNewFile();
		} catch (IOException e) {
		    e.printStackTrace();
		}
		return RE_CSV + fileName;
	}
	
	public static List<String[]> readCsv(String strFile) {
		List<String[]> data = new ArrayList<String[]>();
		try {
			reader = new CSVReader(new FileReader(FOLDER + strFile));
			String[] nextLine;
			while ((nextLine = reader.readNext()) != null) {
				data.add(nextLine);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return data;
	}
	


	public static void writeFileToCsv(String[] str, String file) {
		File f = new File(file);
		try {
			BufferedWriter writer = new BufferedWriter(new FileWriter(f,true));
			CSVWriter cwriter = new CSVWriter(writer,',');
			cwriter.writeNext(str);
			cwriter.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
	}

}
