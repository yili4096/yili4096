package veeva.htmlreport;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import au.com.bytecode.opencsv.CSVReader;
import au.com.bytecode.opencsv.CSVWriter;


public class CsvTools {
	
	
	private static CSVReader reader;
	
	static {
		File directory = new File(Constants.RE_CSV);
		if (!directory.exists()) {
			directory.mkdir();
		}
	}

	public static String createWriteFile(String fileName) {
		try {
	         File file2 = new File(Constants.RE_CSV, fileName);
	         if (!file2.exists()) {
	 			file2.createNewFile();
	 		}
		} catch (IOException e) {
		    e.printStackTrace();
		}
		return Constants.RE_CSV + fileName;
	}
	
	public static List<String[]> readCsv(String strFile) {
		List<String[]> data = new ArrayList<String[]>();
		try {
			reader = new CSVReader(new FileReader(Constants.FOLDER + strFile));
			String[] nextLine;
			while ((nextLine = reader.readNext()) != null) {
				data.add(nextLine);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return data;
	}
	


	public static void writeFileToCsv(String[] str, String file) {
		File f = new File(file);
		try {
			BufferedWriter writer = new BufferedWriter(new FileWriter(f,true));
			CSVWriter cwriter = new CSVWriter(writer,',');
			cwriter.writeNext(str);
			cwriter.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
	}

}
