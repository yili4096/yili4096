package veeva.htmlreport;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class StringUtil {

	/**
	 * 判断字符串是否为空
	 */
	public static boolean isEmpty(String str) {
		if (str == null || str.length() <= 0 || str.trim() == null || str.trim().length() <= 0) {
			return true;
		}
		return false;
	}

	/**
	 * 判断字符串是否不为空
	 */
	public static boolean isNotEmpty(String str) {
		return !isEmpty(str);
	}

	public static String subString(String src, int count) {
		if (src == null || src.length() <= count) {
			return src;
		}

		return src.substring(0, count);
	}

	/**
	 * @param str
	 * @return
	 */
	public static boolean isDigital(String str) {
		if (str != null && !str.trim().isEmpty()) {
			Pattern pattern = Pattern.compile("[0-9]+");
			Matcher isNum = pattern.matcher(str);
			if (!isNum.matches()) {
				return false;
			}
			return true;
		} else {
			return false;
		}
	}

	public static int goal(String edit, String view) {
		int goal = 0;
		if (StringUtil.isDigital(edit)) {
			goal += Integer.valueOf(edit);
		} else if (StringUtil.isDigital(view)) {
			goal += Integer.valueOf(view);
		}
		return goal;

	}
}