package veeva.htmlreport;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Constants {

	public static String FOLDER = "C:\\work\\htmlreport\\test0903\\";
	public static String TERRITORY_NAME = "366558";

	public static String CYCLE_PLAN = "cyclePlan.csv";
	public static String CYCLE_PLAN_TARGET = "cyclePlanTarget.csv";
	public static String CYCLE_PLAN_CHANNEL = "cyclePlanChannel.csv";
	public static String CYCLE_PLAN_PRODUCT = "cyclePlanProduct.csv";
	public static String PRODUCT_METRIX = "productMetrix.csv";
	public static String PRODUCT = "product.csv";
	public static String CYCLE_PRODUCT_RELATION = "cycleProductRelation.csv";
	public static String ACCOUNT = "account.csv";
	public static String CALL = "call.csv";

	public static String EXP_TOTAL_GOAL = "exp_total_goal.csv";

	public static String EXP_CALL_BASEINFO = "exp_tab2_12.csv";
	public static String EXP_TAB2_3 = "exp_tab2_3.csv";
	public static String EXP_TAB2_4 = "exp_tab2_4.csv";
	public static String EXP_TAB2_5 = "exp_tab2_5.csv";
	
	public static String NO_SPECIALTY = "NO_SPECIALTY";
	public static String NO_TIER = "NO_TIER";

	public static String RE_CSV = FOLDER + (LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss"))) + "\\";

	public static String getCyclePlanFile() {
		return Constants.FOLDER + Constants.CYCLE_PLAN;
	}

	public static String getCyclePlanTargetFile() {
		return Constants.FOLDER + Constants.CYCLE_PLAN_TARGET;
	}

	public static String getCyclePlanChannelFile() {
		return Constants.FOLDER + Constants.CYCLE_PLAN_CHANNEL;
	}

	public static String getCyclePlanProductFile() {
		return Constants.FOLDER + Constants.CYCLE_PLAN_PRODUCT;
	}

	public static String getProductMetrixFile() {
		return Constants.FOLDER + Constants.PRODUCT_METRIX;
	}

	public static String getProductFile() {
		return Constants.FOLDER + Constants.PRODUCT;
	}

	public static String getCycleProductRelationFile() {
		return Constants.FOLDER + Constants.CYCLE_PRODUCT_RELATION;
	}

	public static String getAccountFile() {
		return Constants.FOLDER + Constants.ACCOUNT;
	}

	public static String getCallFile() {
		return Constants.FOLDER + Constants.CALL;
	}

	public static String getExpTotalGoalFile() {
		return Constants.RE_CSV + Constants.EXP_TOTAL_GOAL;
	}

	public static String getExpCallFile() {
		return Constants.RE_CSV + Constants.EXP_CALL_BASEINFO;
	}

	public static String getExpTab2_3File() {
		return Constants.RE_CSV + Constants.EXP_TAB2_3;
	}

	public static String getExpTab2_4File() {
		return Constants.RE_CSV + Constants.EXP_TAB2_4;
	}

	public static String getExpTab2_5File() {
		return Constants.RE_CSV + Constants.EXP_TAB2_5;
	}
}
